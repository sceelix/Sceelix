﻿using Sceelix.Core.Annotations;
using Sceelix.Core.Data;
using Sceelix.Core.IO;
using Sceelix.Core.Parameters;
using Sceelix.Core.Procedures;

namespace $rootnamespace$
{
    [Procedure("$guid1$",Label="$safeitemname$")]
    public class $safeitemname$ : SystemProcedure
    {
        private readonly SingleInput<IEntity> _input = new SingleInput<IEntity>("Input");
        private readonly Output<IEntity> _output = new Output<IEntity>("Output");

        private readonly StringParameter _parameter = new StringParameter("Parameter", "");
        private readonly IntParameter _secondParameter = new IntParameter("Second Parameter", 0){MinValue = 0, MaxValue = 10};

        protected override void Run()
        {

        }
    }
}
