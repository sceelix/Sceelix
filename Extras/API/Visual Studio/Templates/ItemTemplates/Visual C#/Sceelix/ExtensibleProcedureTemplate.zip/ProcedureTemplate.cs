﻿using Sceelix.Core.Annotations;
using Sceelix.Core.Data;
using Sceelix.Core.IO;
using Sceelix.Core.Parameters;
using Sceelix.Core.Procedures;

namespace $rootnamespace$
{
	public abstract class MyExtensibleParameter : CompoundParameter
    {
        protected MyExtensibleParameter(string label)
            : base(label)
        {
        }
    }

    public class MySubExtensibleParameter : MyExtensibleParameter
    {
        protected MySubExtensibleParameter()
            : base("My Name")
        {
        }
    }
	
	
    [Procedure("$guid1$",Label="$safeitemname$")]
    public class $safeitemname$ : SystemProcedure
    {
        private readonly SingleInput<IEntity> _input = new SingleInput<IEntity>("Input");
        private readonly Output<IEntity> _output = new Output<IEntity>("Output");

        private readonly SelectListParameter<MyExtensibleParameter> _parameterPrimitive = new SelectListParameter<MyExtensibleParameter>("Primitive");
		
        protected override void Run()
        {

        }
    }
}
