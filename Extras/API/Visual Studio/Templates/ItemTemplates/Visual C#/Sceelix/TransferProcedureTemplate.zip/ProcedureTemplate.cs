﻿using Sceelix.Core.Annotations;
using Sceelix.Core.Data;
using Sceelix.Core.Parameters;
using Sceelix.Core.Procedures;

namespace $rootnamespace$
{
    [Procedure("$guid1$",Label="$safeitemname$")]
    public class $safeitemname$ : TransferProcedure<IEntity>
    {		
        private readonly StringParameter _parameter = new StringParameter("Parameter", "");
        private readonly IntParameter _secondParameter = new IntParameter("Second Parameter", 0);

        protected override IEntity Process(IEntity entity)
        {
            return entity;
        }
    }
}
