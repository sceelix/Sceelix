============================
Sceelix Samples
Author: Sceelix
============================

The following project contains several demos, examples and otherwise materials with the purpose of demonstrating and explaining the available features in Sceelix.

Contains assets from https://www.CC0Textures.com, licensed under CC0 1.0 Universal.

Contains textures from https://www.sharetextures.com, licensed as  CC0.

Contains textures from https://texturehaven.com/, licensed as CC0.

Card textures by Byron Knoll (http://code.google.com/p/vector-playing-cards) downloaded from https://opengameart.org/content/playing-cards-vector-png.

