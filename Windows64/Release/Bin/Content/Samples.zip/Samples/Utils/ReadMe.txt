==============================================
Utils
Author: Sceelix
==============================================

This is a folder where graphs that perform simple, but recurrent operations are stored.